﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Controllers
{
    public class LoggedOnController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
